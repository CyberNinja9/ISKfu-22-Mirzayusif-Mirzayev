#include "stm32f4xx.h"

void delay_ms(int ms) {
    for (int i = 0; i < ms * 1000; i++);
}

void GPIO_Init(void) {
    RCC->AHB1ENR |= (1 << 3);

    GPIOD->MODER |= (1 << (12 * 2)) | (1 << (15 * 2));
}

int main(void) {
    GPIO_Init();

    while (1) {
        GPIOD->ODR |= (1 << 12) | (1 << 15);
        delay_ms(1000);

        GPIOD->ODR &= ~(1 << 12);
        GPIOD->ODR |= (1 << 15);
        delay_ms(1000);


        GPIOD->ODR |= (1 << 12);
        GPIOD->ODR &= ~(1 << 15);
        delay_ms(1000);
    }
}
