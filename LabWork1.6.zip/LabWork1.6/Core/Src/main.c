#include "stm32f4xx.h"
#include "stm32f4xx_hal.h"

void SystemClock_Config(void);
void GPIO_Init(void);

int main(void) {
    HAL_Init();
    SystemClock_Config();
    GPIO_Init();

    uint8_t buttonPressed = 0;
    uint32_t delay_ms = 1000;  // Initial blink delay = 1 second

    while (1) {
        // Toggle Red LED (PD14)
        HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_14);
        HAL_Delay(delay_ms);

        // Check button
        if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET) {
            if (buttonPressed == 0) {
                delay_ms += 2000;  // Increase blink delay by 2 seconds
                buttonPressed = 1;
            }
        } else {
            buttonPressed = 0;
        }
    }
}

void GPIO_Init(void) {
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Red LED (PD14)
    GPIO_InitStruct.Pin = GPIO_PIN_14;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    // User Button (PA0)
    GPIO_InitStruct.Pin = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void SystemClock_Config(void) {

}
